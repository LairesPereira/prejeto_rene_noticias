from art import *

tprint('coffe', font='bulbhead')